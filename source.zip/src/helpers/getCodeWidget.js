export default () => {
    return window.AMOWIDGET.ns.split(':')[1];
}