export const INITIAL_PHONES = '@@amo/INITIAL_PHONES';

export const ADD_PHONE = '@@amo/ADD_PHONE';
export const REMOVE_PHONE = '@@amo/REMOVE_PHONE';