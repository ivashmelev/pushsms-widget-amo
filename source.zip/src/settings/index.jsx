import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(
    <div></div>,
    document.getElementById('root'),
);